package com.example.cs360project;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

import java.util.Objects;

public class SetWeightActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Objects.requireNonNull(getSupportActionBar()).hide();

        // Initialize the database helper
        UserDatabase dbUser = new UserDatabase(this);

        Intent intent = getIntent();
        int userId = intent.getIntExtra("USER_ID", -1); // Default is -1 if no user ID is passed

        if (userId == -1) { // If not found in Intent, retrieve from SharedPreferences
            SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
            userId = sharedPreferences.getInt("USER_ID", -1);
        }

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_set_weight);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button weightButton = findViewById(R.id.logWeightButton);
        int finalUserId = userId;
        weightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Find the EditText field
                EditText weightEditText = findViewById(R.id.setWeightText);
                // Get the text from the EditText and convert it to a string
                int weight = Integer.parseInt(weightEditText.getText().toString());

                // Find the EditText field
                EditText dateEditText = findViewById(R.id.setDateText);
                // Get the text from the EditText and convert it to a string
                String date = dateEditText.getText().toString();

                if (dbUser.insertOrUpdateDailyWeight(finalUserId, date, weight)) {

                    Toast.makeText(SetWeightActivity.this, "Your new daily weight has been logged!", Toast.LENGTH_SHORT).show();

                    weightEditText.setText("");
                    dateEditText.setText("");

                    int currentGoalWeight = dbUser.getGoalWeight(finalUserId);

                    if (weight == currentGoalWeight) {
                        Toast.makeText(SetWeightActivity.this, "CONGRATULATIONS! You reached your goal weight!", Toast.LENGTH_SHORT).show();
                    }
                }


            }
        });

        //Bottom Navigation Menu Handling
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);

        // Set default selected item to Dashboard
        bottomNavigationView.setSelectedItemId(R.id.nav_profile);

        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId(); // Store item ID

                if (itemId == R.id.nav_home) {
                    startActivity(new Intent(SetWeightActivity.this, MainActivity.class));
                    return true;
                }
                else if (itemId == R.id.nav_profile) {
                    startActivity(new Intent(SetWeightActivity.this, DashboardActivity.class));
                    return true;
                }
                else if (itemId == R.id.nav_settings) {
                    startActivity(new Intent(SetWeightActivity.this, SettingsActivity.class));
                    return true;
                }

                return false;
            }
        });

    }
}