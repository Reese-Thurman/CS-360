package com.example.cs360project;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;
import android.util.Log;

import java.util.ArrayList;

public class UserDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "users.db";
    private static final int VERSION = 1;


    private static final String USER_TABLE = "users";
    private static final String WEIGHT_TABLE = "weight";
    private static final String USER_ID = "id";
    private static final String USERNAME = "username";
    private static final String PASSWORD = "password";
    private static final String GOAL_WEIGHT = "goal_weight";

    // Weight Entries Table Columns
    private static final String ENTRY_ID = "entry_id";
    private static final String USER_ID_FK = "user_id_fk";
    private static final String WEIGHT = "weight";
    private static final String DATE = "entry_date";


    public UserDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    //Insert a new user
    public boolean insertUser(String username, String password, int weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);
        values.put("goal_weight", weight);

        long result = db.insert("users", null, values);
        db.close();
        return result != -1; // Returns true if insert was successful, otherwise false
    }

    // Insert or update daily weight entry
    public boolean insertOrUpdateDailyWeight(int userId, String date, int weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(WEIGHT, weight); // New weight
        values.put(USER_ID_FK, userId); // User ID
        values.put(DATE, date); // Date of the entry

        // Try to update the entry for the given userId and date
        int rowsUpdated = db.update(WEIGHT_TABLE, values, USER_ID_FK + " = ? AND " + DATE + " = ?",
                new String[]{String.valueOf(userId), date});

        // If rows were updated, return true (successfully updated)
        if (rowsUpdated > 0) {
            db.close();
            return true;
        } else {
            // If no rows were updated, insert the new weight entry
            long result = db.insert(WEIGHT_TABLE, null, values);
            db.close();

            return result != -1; // Returns true if insert was successful, otherwise false
        }
    }

    // Deletes a daily weight entry for a user on a specific date
    public boolean deleteDailyWeight(int userId, String date) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Delete the weight entry for given userId and date
        int rowDeleted = db.delete(WEIGHT_TABLE, USER_ID_FK + " = ? AND " + DATE + " = ?",
                new String[]{String.valueOf(userId), date});

        db.close();
        return rowDeleted > 0; // Returns true if the row was deleted, otherwise false
    }

    public boolean updateGoalWeight(int userId, int newGoalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(GOAL_WEIGHT, newGoalWeight); // Set the new goal weight value

        // Update the user record where the user_id matches
        int rowsAffected = db.update(USER_TABLE, values, USER_ID + " = ?", new String[]{String.valueOf(userId)});

        db.close(); // Close the database

        // Return true if a row was updated, otherwise false
        return rowsAffected > 0;
    }

    //Check if a user exists (for login)
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username = ? AND password = ?",
                new String[]{username, password});

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists; // Returns true if user exists, otherwise false
    }

    // Get all weight entries sorted by date
    public ArrayList<String> getAllWeightEntries(int userId) {
        ArrayList<String> weightEntries = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Query to get all weight entries ordered by date
        Cursor cursor = db.rawQuery("SELECT weight, entry_date FROM " + WEIGHT_TABLE +
                        " WHERE " + USER_ID_FK + " = ? ORDER BY " + DATE + " ASC",
                new String[]{String.valueOf(userId)});

        // Check if cursor has data
        if (cursor.moveToFirst()) {
            // Find the indices of the columns
            int weightColumnIndex = cursor.getColumnIndex(WEIGHT);
            int dateColumnIndex = cursor.getColumnIndex(DATE);

            // Ensure the column indices are valid (not -1)
            if (weightColumnIndex != -1 && dateColumnIndex != -1) {
                do {
                    int weight = cursor.getInt(weightColumnIndex);
                    String date = cursor.getString(dateColumnIndex);
                    weightEntries.add(weight + " lbs:" + date); // Format the entry as weight:date
                } while (cursor.moveToNext());
            } else {
                // Log the error case if column index is invalid
                Log.e("UserDatabase", "Column index is invalid! Make sure the column names are correct!");
            }
        }
        cursor.close();
        db.close();
        return weightEntries;
    }

    //Finds a user ID associated with a userID
    public int getUserId(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        int userId = -1;  // Default to -1 if no user found

        // Query to get the user ID based on the username
        Cursor cursor = db.rawQuery("SELECT " + USER_ID + " FROM " + USER_TABLE + " WHERE " + USERNAME + " = ?", new String[]{username});


        if (cursor.moveToFirst()) {
            // Check if the column exists before accessing it
            int userIdColumnIndex = cursor.getColumnIndex(USER_ID);

            // Ensure the column exists
            if (userIdColumnIndex != -1) {
                // Get the user ID from the cursor
                userId = cursor.getInt(userIdColumnIndex);
            }
            else { //Log an error if column isn't found
                Log.e("UserDatabase", "Error! Column " + USER_ID + " does not exist");
            }

            cursor.close();  // Close the cursor when done
        }

        db.close();  // Close the database
        return userId;
    }

    // Get current weight goal
    public int getGoalWeight(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + GOAL_WEIGHT + " FROM " + USER_TABLE + " WHERE " + USER_ID + " = ?", new String[]{String.valueOf(userId)});

        int goalWeight = -1;  // Default value
        if (cursor.moveToFirst()) {
            // Get column index for goal weight
            int goalWeightIndex = cursor.getColumnIndex(GOAL_WEIGHT);
            if (goalWeightIndex != -1) {
                goalWeight = cursor.getInt(goalWeightIndex);
            }
            else {
                Log.e("UserDatabase", "Error! Column 'goal_weight' not found.");
            }
        }
        else {
            Log.e("UserDatabase", "Error! No record found for user ID: " + userId);
        }
        cursor.close();
        return goalWeight;
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        // Creating the users table with the goal weight column
        db.execSQL("CREATE TABLE " + USER_TABLE + " (" +
                USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                USERNAME + " TEXT UNIQUE NOT NULL, " +
                PASSWORD + " TEXT NOT NULL, " +
                GOAL_WEIGHT + " INTEGER);");

        // Creating the weight entries table with a foreign key reference to the user table
        db.execSQL("CREATE TABLE " + WEIGHT_TABLE + " ("
                + ENTRY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + USER_ID_FK + " INTEGER, "
                + WEIGHT + " INTEGER, "
                + DATE + " TEXT, "
                + "FOREIGN KEY(" + USER_ID_FK + ") REFERENCES " + USER_TABLE + "(" + USER_ID + "));");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + USER_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + WEIGHT_TABLE);
        onCreate(db);
    }
    }
