package com.example.cs360project;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import androidx.appcompat.widget.SwitchCompat;

import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;


public class SettingsActivity extends AppCompatActivity {

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);


        setContentView(R.layout.activity_settings);


        // Load saved theme setting
        SharedPreferences sharedPreferences;
        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        boolean isDarkModeOn = sharedPreferences.getBoolean("DARK_MODE", false);



     /*   if (isDarkModeOn) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        } */


        //Check if switch is checked to determine whether to dark mode on or off,
        //then updates theme accordingly




        SharedPreferences finalSharedPreferences = sharedPreferences;
        SwitchCompat darkModeSwitch = findViewById(R.id.darkModeSwitch);

        darkModeSwitch.setChecked(isDarkModeOn);




        SharedPreferences finalSharedPreferences1 = sharedPreferences;
        darkModeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {

            // Apply theme
            // Update the stored preference
            SharedPreferences.Editor editor = finalSharedPreferences1.edit();
            editor.putBoolean("DARK_MODE", isChecked);
            editor.apply();
            if (buttonView.isPressed()) {  // Only trigger if not setting the state

                // Apply the theme based on the switch state
                if (isChecked) {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                } else {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                }

            }



        });

        // Set the switch to the correct state based on the saved preference




        Objects.requireNonNull(getSupportActionBar()).hide();

        


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });






        // Retrieve the user ID passed from Dashboard
        Intent intent = getIntent();
        int userId = intent.getIntExtra("USER_ID", -1); // Default is -1 if no user ID is passed

        if (userId == -1) { // If not found in Intent, retrieve from SharedPreferences
            sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
            userId = sharedPreferences.getInt("USER_ID", -1);
        }

        //Bottom Navigation Menu Handling
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);

        // Set default selected item to Dashboard
        bottomNavigationView.setSelectedItemId(R.id.nav_settings);

        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId(); // Store item ID

                if (itemId == R.id.nav_home) {
                    startActivity(new Intent(SettingsActivity.this, MainActivity.class));
                    return true;
                } else if (itemId == R.id.nav_profile) {
                    startActivity(new Intent(SettingsActivity.this, DashboardActivity.class));
                    return true;
                } else if (itemId == R.id.nav_settings) {
                    startActivity(new Intent(SettingsActivity.this, SettingsActivity.class));
                    return true;
                }

                return false;
            }
        });
    }
}



