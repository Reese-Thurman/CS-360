package com.example.cs360project;
import static android.content.Context.MODE_PRIVATE;
import android.content.SharedPreferences;
import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder> {
    private ArrayList<String> dataList;
    private Context context;

    public DataAdapter(DashboardActivity dashboardActivity, ArrayList<String> dataList) {
        this.dataList = dataList;
        this.context = dashboardActivity;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView dateViewData;  // For date
        TextView weightViewData;  // For weight
        Button buttonDelete; // Delete button


        public ViewHolder(View itemView) {
            super(itemView);
            dateViewData = itemView.findViewById(R.id.dateText);
            weightViewData = itemView.findViewById(R.id.weightText);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Assuming the data format is "weight:date"
        String data = dataList.get(position);
        String[] parts = data.split(":");  // Split the string into weight and date

        // Set the respective values to the correct TextViews
        holder.weightViewData.setText(parts[0]);  // Set weight
        holder.dateViewData.setText(parts[1]);    // Set date

        holder.buttonDelete.setOnClickListener(v -> {
            dataList.remove(position); // Remove item
            notifyItemRemoved(position); // Refresh UI

            // Now delete it from the database
            // Call the method to delete from the database
            UserDatabase dbUser = new UserDatabase(context);
            String dateToDelete = parts[1];
            SharedPreferences sharedPreferences = context.getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
            int userId = sharedPreferences.getInt("USER_ID", -1); // Default to -1 if no userId is found
            boolean isDeleted = dbUser.deleteDailyWeight(userId, dateToDelete);

        });
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }
}

