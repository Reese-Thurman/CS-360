package com.example.cs360project;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;


import android.view.MenuItem;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarItemView;
import com.google.android.material.navigation.NavigationBarView;
import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;


public class DashboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        Objects.requireNonNull(getSupportActionBar()).hide();

        // Initialize the database helper
        UserDatabase dbUser = new UserDatabase(this);

        // Retrieve the user ID passed from MainActivity
        Intent intent = getIntent();
        int userId = intent.getIntExtra("USER_ID", -1); // Default is -1 if no user ID is passed

        if (userId == -1) { // If not found in Intent, retrieve from SharedPreferences
            SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
            userId = sharedPreferences.getInt("USER_ID", -1);
        }

        // Get the current goal weight from the database
        int currentGoalWeight = dbUser.getGoalWeight(userId); // Get the goal weight for the user

        // Set the current goal weight in the TextView
        TextView goalWeightTextView = findViewById(R.id.goalView);
        if (currentGoalWeight != -1) {
            goalWeightTextView.setText("Current Weight Goal: " + currentGoalWeight + " lbs");
        }
        else {
            goalWeightTextView.setText("No weight goal set.");
        }

        // Get all weight entries for the user
        ArrayList<String> weightData = dbUser.getAllWeightEntries(userId);

        /*
        // Sample data (weight:date format)
        ArrayList<String> sampleData = new ArrayList<>();
        sampleData.add("180 lbs:02/08/2025");
        sampleData.add("175 lbs:02/09/2025"); */


        // Set up RecyclerView and adapter
        // Check if there are no entries
        if (!weightData.isEmpty()) {

            RecyclerView recyclerView = findViewById(R.id.recyclerView);
            DataAdapter adapter = new DataAdapter(DashboardActivity.this, weightData);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            recyclerView.setAdapter(adapter);
        }

        Button buttonGoToWeight = findViewById(R.id.setWeightButton);
        buttonGoToWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DashboardActivity.this, SetWeightActivity.class);
                startActivity(intent);
            }
        });

        Button buttonGoToGoal = findViewById(R.id.setGoalButton);
        buttonGoToGoal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DashboardActivity.this, SetGoalActivity.class);
                startActivity(intent);
            }
        });

        //Bottom Navigation Menu Handling
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);

        // Set default selected item to Dashboard
        bottomNavigationView.setSelectedItemId(R.id.nav_profile);

        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId(); // Store item ID

                if (itemId == R.id.nav_home) {
                    startActivity(new Intent(DashboardActivity.this, MainActivity.class));
                    return true;
                }

                else if (itemId == R.id.nav_profile) {
                    startActivity(new Intent(DashboardActivity.this, DashboardActivity.class));
                    return true;
                }

                else if (itemId == R.id.nav_settings) {
                    startActivity(new Intent(DashboardActivity.this, SettingsActivity.class));
                    return true;
                }

                return false;
            }
        });
    }

}