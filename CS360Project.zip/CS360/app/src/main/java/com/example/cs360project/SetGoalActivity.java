package com.example.cs360project;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

import java.util.Objects;

public class SetGoalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Objects.requireNonNull(getSupportActionBar()).hide();

        // Initialize the database helper
        UserDatabase dbUser = new UserDatabase(this);

        Intent intent = getIntent();
        int userId = intent.getIntExtra("USER_ID", -1); // Default is -1 if no user ID is passed

        if (userId == -1) { // If not found in Intent, retrieve from SharedPreferences
            SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
            userId = sharedPreferences.getInt("USER_ID", -1);
        }

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_set_goal);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Get the current goal weight from the database
        int currentGoalWeight = dbUser.getGoalWeight(userId);

        // Set the current goal weight in the TextView
        TextView currentGoalText = findViewById(R.id.currentGoalText);
        currentGoalText.setText("Current Weight Goal: " + currentGoalWeight + " lbs");

        Button goalButton = findViewById(R.id.setGoalButton2);
        int finalUserId = userId;
        goalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Find the EditText field
                EditText goalEditText = findViewById(R.id.setGoalText);
                // Get the text from the EditText and convert it to a string
                int goal = Integer.parseInt(goalEditText.getText().toString());

                if (dbUser.updateGoalWeight(finalUserId, goal)) {
                    // Get the current goal weight from the database
                    int currentGoalWeight = dbUser.getGoalWeight(finalUserId);
                    currentGoalText.setText("Current Weight Goal: " + currentGoalWeight + " lbs");
                    Toast.makeText(SetGoalActivity.this, "Your new Goal Weight has been set!", Toast.LENGTH_SHORT).show();
                }


            }
        });

        //Bottom Navigation Menu Handling
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);

        // Set default selected item to Dashboard
        bottomNavigationView.setSelectedItemId(R.id.nav_profile);

        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId(); // Store item ID

                if (itemId == R.id.nav_home) {
                    startActivity(new Intent(SetGoalActivity.this, MainActivity.class));
                    return true;
                } else if (itemId == R.id.nav_profile) {
                    startActivity(new Intent(SetGoalActivity.this, DashboardActivity.class));
                    return true;
                } else if (itemId == R.id.nav_settings) {
                    startActivity(new Intent(SetGoalActivity.this, SettingsActivity.class));
                    return true;
                }

                return false;
            }
        });
    }
}