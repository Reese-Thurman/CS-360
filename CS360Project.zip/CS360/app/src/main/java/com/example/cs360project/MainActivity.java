package com.example.cs360project;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.Manifest;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import java.util.Objects;


public class MainActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 777;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Initialize the database
        UserDatabase dbUser = new UserDatabase(this);
        // This will create or open the database
        dbUser.getWritableDatabase();

        //SQLiteDatabase db = dbUser.getWritableDatabase();

        // Check to see if user has selected dark mode
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        boolean isDarkModeOn = sharedPreferences.getBoolean("DARK_MODE", false);

        if (isDarkModeOn) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        }
        else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }


        // Link MainActivity to active_main.xml layout
        setContentView(R.layout.activity_main);

        Button buttonGoToDashboard = findViewById(R.id.signInButton);
        buttonGoToDashboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Find the EditText field
                EditText usernameEditText = findViewById(R.id.usernameText);
                // Get the text from the EditText and convert it to a string
                String username = usernameEditText.getText().toString();

                // Find the EditText field
                EditText passwordEditText = findViewById(R.id.passwordText);
                // Get the text from the EditText and convert it to a string
                String password = passwordEditText.getText().toString();

                if (dbUser.checkUser(username, password) && (!username.isEmpty() || !password.isEmpty())) {

                    // Get the user ID after successful login
                    int userId = dbUser.getUserId(username);

                    //Store the userID so it can be accessed by any activity
                    SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putInt("USER_ID", userId);
                    editor.apply();

                    Intent intent = new Intent(MainActivity.this, DashboardActivity.class);
                    // Pass the user ID to DashboardActivity
                    intent.putExtra("USER_ID", userId);
                    startActivity(intent);
                }

                else {

                    // Show incorrect login message
                    Toast.makeText(MainActivity.this, "Incorrect login", Toast.LENGTH_SHORT).show();

                }
            }
        });

        Button buttonSignUp = findViewById(R.id.signUpButton);
        buttonSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Find the EditText field
                EditText usernameEditText = findViewById(R.id.usernameText);
                // Get the text from the EditText and convert it to a string
                String username = usernameEditText.getText().toString();

                // Find the EditText field
                EditText passwordEditText = findViewById(R.id.passwordText);
                // Get the text from the EditText and convert it to a string
                String password = passwordEditText.getText().toString();

                if (dbUser.insertUser(username, password, 0)) {

                    // Get the user ID after successful login
                    int userId = dbUser.getUserId(username);

                    Intent intent = new Intent(MainActivity.this, DashboardActivity.class);
                    // Pass the user ID to DashboardActivity
                    intent.putExtra("USER_ID", userId);
                    startActivity(intent);
                }

                else {

                    // Show incorrect login message
                    Toast.makeText(MainActivity.this, "Error: Please Try Again", Toast.LENGTH_SHORT).show();

                }
            }
        });

        // Hide Action Bar
        Objects.requireNonNull(getSupportActionBar()).hide();

        // Check SMS permission when the app starts
        checkSmsPermission();

    }

    // Check for SEND_SMS permission
    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            // If permission is not granted, request permission
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        }
    }

    // Handle the permission request result
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted. You will receive goal weight notifications", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied. You will not receive goal weight notifications", Toast.LENGTH_SHORT).show();
            }
        }
    }

    }



